# @victframework/store-postgres indexed review candidate

This private review package retains the existing legacy `createPostgresStores` export. `createIndexedPostgresStores` explicitly selects the indexed layout and verifies the schema marker, namespace and writer epoch. Provision it outside request handling using `indexedSchemaStatements` from `@victframework/store-postgres/operator`. TLS and connection settings follow the legacy driver. Set `tls: 'disable-loopback-only'` for an owned disposable server. Use the named PostgreSQL database in the DSN.

The operator subpath and `vict-postgres-migrate` command support the fixed disposable VHOST-011 rehearsal topology. The root store does not start migration or receive a writer epoch automatically. Indexed requests require the operator's namespace and callback admission records. The operator inspection function opens staged reads in PostgreSQL read-only transactions.

Install this review tarball with the exact Runtime/C12 closure named in `@victframework/store-postgres/provenance.json`. Its build metadata distinguishes it from the released legacy artifact while retaining compatibility with the pinned Mastra dependency. The dispatcher repair remains in the VICT server source and its exact Git identity is in the package provenance.
