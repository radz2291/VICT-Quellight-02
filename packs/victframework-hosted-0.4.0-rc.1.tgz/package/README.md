# Bounded VICT requests

`@victframework/hosted` composes authenticated Node requests around existing VICT
runtime and durable storage authority. It has no model, database-driver, Vercel,
or application-schema dependency. PostgreSQL persistence is supplied through
`@victframework/store-postgres`; optional Mastra composition stays in its own package.

The host supplies authentication, input parsing and a request session. Opening a
session acquires a durable lease and restores the exact activation. Its `execute`
callback must use `stores.forLease(lease)` and equivalently fenced model storage
for every mutation. The context's abort signal and `requireTime()` allow bounded
units to stop starting work before the request budget ends. The callback grants no
effect permission and must not use an unguarded store to bypass the lease.

When work finishes or exceeds its budget, the handler releases the ownership
generation, reads actor-authorized durable state, and awaits request-owned cleanup.
Release and writes must be serialized by the storage adapter in the same database
transaction. A completed durable run is reported as completed even if an external
call subsequently throws. Only a durable `waiting` state receives a continuation
descriptor. `running`, missing state, lease-release failure and database loss
produce `uncertain` and require inspecting durable state. A blocked run is never
automatically retried.

The continuation descriptor contains run ID, activation version and record
revision. It is an optimistic concurrency descriptor, **not** an authorization
token. Every continuation request must authenticate again, verify actor ownership,
and restore that exact activation. It must not activate the current default and
continue an older run with it.

The deadline does not undo an external effect or forcibly terminate arbitrary
JavaScript. Work ignoring abort may continue computing after its lease is released;
its guarded writes are fenced. Use provider/HTTP/database timeouts and durable
effect receipts for issued effects. If the process dies or the settlement reserve
expires, cleanup is explicitly `unconfirmed`. The next request inspects the durable
receipt; it must not infer that the effect did not happen. Late promises have
rejection handlers; background completion is not required for correctness.

`readHostedEnvironment()` reads only `VICT_DATABASE_URL`, `VICT_STORAGE_NAMESPACE`,
`VICT_POOL_MAX`, `VICT_DATABASE_CA_PEM`, `VICT_WORK_MS`, and `VICT_SETTLEMENT_MS`.
Keep its result server-side. TLS verification is mandatory; URL SSL parameters are
rejected because drivers may let them replace explicit TLS policy. Local database
tests use the adapter's explicit loopback mode outside this environment reader.

Compose operational factory options explicitly:
`{ connectionString: env.connectionString, namespace: env.namespace, maxConnections:
env.poolMax, tls: env.tls, migrate: false }`. The returned TLS object contains only an
optional custom CA; the PostgreSQL factory always enables certificate verification.

The optional `@victframework/hosted/vercel` export provides a conservative 60 second
Node configuration: 45 seconds of work, 10 seconds for settlement, 5 seconds to
return. No scheduler is enabled. Vercel's documented free Fluid maximum was
300 seconds and 2 GB on 16 November 2026; actual free usage quotas and eligibility
still apply. See [host composition and qualification notes](../../docs/hosted-vercel/HOSTING.md).

Schema migrations are an explicit operator-owned command, outside request serving.
Open PostgreSQL with `migrate: true` only there and await close. Runtime connections
use `migrate: false` and refuse missing or incompatible schema. Never reset another
application's schema/password, silently migrate on cold start, or upgrade a plan.

For generic application composition, see `examples/hosted-workflow`. All HTTP and
database errors emitted by this package use fixed codes, and its optional log sink
receives codes only. Application result responses are intentionally separate from
operational logs and remain the host's authorized content boundary.

Trusted callbacks can throw `HostedRequestRefusal` for finite authorization,
activation, idempotency or stale-continuation refusals. These return 403/409 after
fencing and cleanup; an older completed run cannot turn a conflicting new command
into success. Observations must mark `effects: 'uncertain'` when an unresolved receipt
remains; a durable wait by itself does not prove that such an effect is safe to retry.
