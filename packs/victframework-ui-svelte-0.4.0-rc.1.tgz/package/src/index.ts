export { default as ControlScope } from './ControlScope.svelte';
export { default as DocumentHost } from './document/DocumentHost.svelte';
export { default as DocumentRenderNode } from './document/RenderNode.svelte';
export * from './document/extensions.js';
export { b1CatalogDescriptors } from './catalog/components/descriptors.js';
export { b1CatalogImplementations } from './catalog/components/implementations.js';
export {
  occurrenceKey,
  rootClassFor,
  styleRulesToCss,
  uniqueRepeatKeys,
  walkInstructions,
  nodeIdsOf,
} from './document/logic.js';
export { default as Select } from './Select.svelte';
export { default as Popover } from './Popover.svelte';
export { default as Tooltip } from './Tooltip.svelte';
export { default as RecordsTable } from './RecordsTable.svelte';
export { default as AppShell } from './AppShell.svelte';
export { default as Button } from './Button.svelte';
export { default as StatusBadge } from './StatusBadge.svelte';
export { default as Feedback } from './Feedback.svelte';
export { default as ActionFeedback } from './ActionFeedback.svelte';
export { default as Tabs } from './Tabs.svelte';
export { default as Form } from './Form.svelte';
export { default as FormField } from './FormField.svelte';
export { default as Overlay } from './Overlay.svelte';
export { default as Text } from './Text.svelte';
export { default as DataView } from './DataView.svelte';
export { default as List } from './List.svelte';
export { default as Detail } from './Detail.svelte';
export { default as Chart } from './Chart.svelte';
export { default as Conversation } from './Conversation.svelte';
export { default as Count } from './Count.svelte';
export { default as ComponentSlot } from './ComponentSlot.svelte';

// ---------------------------------------------------------------------------
// Renderer surface: the PERMANENT Svelte ApplicationRenderer implementation
// lives in this package (moved from @victframework/renderer-svelte, which is
// now only a compatibility facade re-exporting everything below).
// ---------------------------------------------------------------------------

export { default as VitApp } from './VitApp.svelte';
export { createVictRenderer, RENDERER_ID, RENDERER_REVISION } from './renderer.js';
export { renderVictApplication } from './mount.svelte.js';
export type { MountedVictApplication, RenderVictApplicationOptions } from './mount.svelte.js';
export {
  resolveRoute,
  matchPath,
  substitutePathParams,
  deriveRowActionInput,
  resolveRowDetailLink,
  collectSurfaces,
  declaredSurfaceViewIds,
  isComponentSource,
  resolveComponentSource,
  resolveComponentProps,
  resolveComponentActionInput,
  themeVariables,
  validatePlanForRenderer,
  BUILT_IN_ROLES,
  type VictPlanView,
  type ResolvedRoute,
  type ActionResult,
  type ViewDatum,
  type ComponentSourceBinding,
  type ComponentSourceContext,
} from './logic.js';
export { RendererDiagnostic } from '@victframework/application/renderer';

// ---- U1 document renderer (vict.ui-render-plan@1 consumer) ------------------
export * from './document/logic.js';

export type { UiComponentPresentation, UiComponentTargetAttributes, UiActionStateConnection, UiComponentActionStatus } from './document/extensions.js';

export { b2CatalogDescriptors } from './catalog/components/b2-descriptors.js';
export { b2CatalogImplementations } from './catalog/components/b2-implementations.js';

export { b3CatalogDescriptors } from './catalog/components/b3-descriptors.js';
export { b3CatalogImplementations } from './catalog/components/b3-implementations.js';

export { b4CatalogDescriptors } from './catalog/components/b4-descriptors.js';
export { b4CatalogImplementations } from './catalog/components/b4-implementations.js';

export { b5CatalogDescriptors } from './catalog/components/b5-descriptors.js';
export { b5CatalogImplementations } from './catalog/components/b5-implementations.js';
export { catalogDescriptors, catalogImplementations } from './catalog/components/catalog.js';
export { catalogAuthoringPackage, catalogAuthoringRegistrations } from './catalog/components/authoring.js';
export { withAuthoringRules, runtimeAuthoringIssues } from './document/authoring-runtime.js';
export {default as OwnedDialogContent} from './OwnedDialogContent.svelte';
export {createOwnedDialogBehavior,ownedDialogBranches,isOwnedFocusable,ownedFocusableOrder,restoreOwnedFocus,loopOwnedDialogFocus,lockOwnedDialogViewport,type OwnedDialogOptions} from './owned-dialog.js';
export {registerOwnedPopupLayer,resolveOwnedPopupOwner,isOwnedPopupTarget,hasCompetingOwnedPopupOwner,isOwnedElementRendered,isOwnedPopupSourceVisible,isOwnedPopupSourceAvailable,isOwnedPopupSourceTarget,ownedDocumentHasFocus,observeOwnedPopupSource,ownedPopupBranches,positionOwnedPopup,type OwnedPopupLayer,type OwnedPopupLayerOptions,type OwnedPopupKind,type OwnedPopupEventResult,type OwnedPopupEventContext,type OwnedPopupPositionOptions,type OwnedPopupSourceOptions} from './owned-popup.js';
export {default as OwnedTooltip} from './OwnedTooltip.svelte';
export {default as OwnedHoverCard} from './OwnedHoverCard.svelte';
export {createOwnedTooltipBehavior,type OwnedTooltipOptions} from './owned-tooltip.js';
export {createOwnedHoverCardBehavior} from './owned-tooltip.js';
export {default as OwnedMenuContent} from './OwnedMenuContent.svelte';
export {OWNED_MENU_CONTEXT,createOwnedMenuContext,createOwnedMenuBehavior,ownedMenuItems,focusOwnedMenuItem,ownedMenuTriggerKey,restoreOwnedMenuFocus,type OwnedMenuContext,type OwnedMenuCloseReason} from './owned-menu.js';
