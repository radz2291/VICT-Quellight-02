<script lang="ts">
  import { AlertDialog } from '../alert-dialog.js';
  import type { UiSvelteComponentProps } from '../../document/extensions.js';
  import ActionFeedback from '../../ActionFeedback.svelte';
  import CatalogPortal from './CatalogPortal.svelte';
  import { catalogFocusReturn } from './focus-return.js';
  let { props, io, presentation }: UiSvelteComponentProps = $props();
  let open = $derived(props.open === true);
  let triggerRef = $state<HTMLButtonElement | null>(null);
  const restoreTrigger = catalogFocusReturn(() => triggerRef);
</script>

<AlertDialog.Root bind:open onOpenChange={(next) => io?.emit('openChange', next)}>
  <AlertDialog.Trigger {...presentation?.target('trigger')} disabled={props.disabled === true} bind:ref={triggerRef}>
    {#if io?.slotLabels?.trigger !== undefined}{io.slotLabels.trigger}{:else if io?.slots?.trigger}{@render io.slots.trigger()}{:else}{typeof props.label === 'string' ? props.label : 'AlertDialog'}{/if}
  </AlertDialog.Trigger>
  <CatalogPortal {open} {presentation}>
    <AlertDialog.Overlay />
    <AlertDialog.Content {...presentation?.target('root')} onCloseAutoFocus={restoreTrigger}>
      <AlertDialog.Title>{typeof props.title === 'string' ? props.title : 'Confirm decision'}</AlertDialog.Title>
      <AlertDialog.Description>{typeof props.description === 'string' ? props.description : ''}</AlertDialog.Description>
      {@render io?.slots?.body?.()}
      <div class="vict-actions">
        <AlertDialog.Cancel {...presentation?.target('cancel')}>
          {#if io?.slotLabels?.cancel !== undefined}{io.slotLabels.cancel}{:else if io?.slots?.cancel}{@render io.slots.cancel()}{:else}{typeof props.cancelLabel === 'string' ? props.cancelLabel : 'Cancel'}{/if}
        </AlertDialog.Cancel>
        <AlertDialog.Action {...presentation?.target('action')} disabled={props.disabled === true} aria-disabled={io?.action?.pending || undefined} aria-busy={io?.action?.pending || undefined} onclick={(event) => { if (io?.action?.pending) { event.preventDefault(); return; } io?.emit('confirm'); }}>
          {#if io?.slotLabels?.action !== undefined}{io.slotLabels.action}{:else if io?.slots?.action}{@render io.slots.action()}{:else}{typeof props.confirmLabel === 'string' ? props.confirmLabel : 'Confirm'}{/if}
        </AlertDialog.Action>
      </div>
      <ActionFeedback feedback={io?.action?.feedback} />
    </AlertDialog.Content>
  </CatalogPortal>
</AlertDialog.Root>

{#if !open}<ActionFeedback feedback={io?.action?.feedback} />{/if}
